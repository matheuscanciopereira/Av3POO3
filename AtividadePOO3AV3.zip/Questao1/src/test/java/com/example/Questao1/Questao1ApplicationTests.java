package com.example.Questao1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Questao1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
