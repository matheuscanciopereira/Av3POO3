package com.example.Questao1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Questao1Application {

	public static void main(String[] args) {
		SpringApplication.run(Questao1Application.class, args);
		System.out.print("Conectado");}
}
